//
//  Settings.swift
//  Free The Slaves
//
//  Created by Chirag Chadha on 10/29/16.
//  Copyright © 2016 ChiragChadha. All rights reserved.
//

import UIKit

class Settings: UIViewController, UIPickerViewDataSource, UIPickerViewDelegate {
    
    
    @IBOutlet var organization: UITextField!
    @IBOutlet var district: UITextField!
    
    
    
    let pickerDataSource = ["Arabic","Bengali","Chinese","English","French","German","Hindi","Italian","Japanese","Javanese", "Korean", "Lahnda", "Marathi", "Portuguese", "Russian", "Spanish", "Tamil", "Telugu", "Urdu", "Vietnamese"]
   
    
    @IBOutlet weak var translateView: UIPickerView!
    @IBOutlet weak var pickerView: UIPickerView!
    
    @IBAction func save(_ sender: AnyObject) {
        
        UserDefaults.standard.set(organization.text, forKey: "district")
        
        let numberObject = UserDefaults.standard.object(forKey: "district")
        
        if let num = numberObject as? String{
            print(num)
        }
        
      
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.pickerView.dataSource = self;
        self.pickerView.delegate = self;
        self.translateView.dataSource = self;
        self.translateView.delegate = self;
        
        // Do any additional setup after loading the view, typically from a nib.
        
        //Looks for single or multiple taps.
        let tap: UITapGestureRecognizer = UITapGestureRecognizer(target: self, action: #selector(Form.dismissKeyboard))
        
        //Uncomment the line below if you want the tap not not interfere and cancel other interactions.
        //tap.cancelsTouchesInView = false
        
        view.addGestureRecognizer(tap)
    }
       func dismissKeyboard() {
        //Causes the view (or one of its embedded text fields) to resign the first responder status.
        view.endEditing(true)
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
    @available(iOS 2.0, *)
    public func numberOfComponents(in pickerView: UIPickerView) -> Int{
        return 1
    }
    
    
    // returns the # of rows in each component..
    @available(iOS 2.0, *)
    public func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int{
        return pickerDataSource.count;
    }
    
    @available(iOS 2.0, *)
    public func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String?{
        return pickerDataSource[row]
    }

    
  
    
    
}
