//
//  Form.swift
//  Free The Slaves
//
//  Created by Chirag Chadha on 10/29/16.
//  Copyright © 2016 ChiragChadha. All rights reserved.
//

import UIKit

class Form: UIViewController, UITextFieldDelegate {
    
    @IBOutlet var name: UITextField!
    
    @IBOutlet var comment: UITextField!
    
    
    @IBOutlet var question: UILabel!
    var count:Int = 0
    

    var array: [String] = [
        
        "Traffickers, whether from the village or from outside the village, cannot operate any more.",

        "No one residing in this village is in any form of slavery.",

        "People who migrate from this community for work are NOT being trafficked.",

        "None of the children in this village are being exploited for commercial sex.",

        "None of the children in this village are performing hazardous labor.",

        "Residents in this village know how to protect themselves from trafficking during migration for work. (facilitator questions: In cases where a household member is migrating for work, are they: 1) counseled about the risks? 2) told about the measures to take to protect themselves? and 3) told whomto contact if they find themselves in slavery?)",

       " Residents understand the risks of sending children to distant jobs, e.g. domestic work, mining or stone quarries, and circuses.",

        "Residents are able to identify and pressure known traffickers to leave when they appear in the community",

      "  Residents in this village know how to avoid debt bondage.",

       " Residents understand the risks of early or forced marriage and false offers of marriage",

       " Residents are able to confront domestic violence.",

        "Residents know how to file criminal complaints with the police.",
        
        "Residents understand basic human rights. (facilitator questions: How many residents do you think know about freedom of movement? freedom to join groups and assemble? right to education?)",

        "Residents are able to list some of the country’s legal rights for workers. (facilitator questions: How many residents do you think know about minimum wages? The right to protection from violence and threats in the workplace? the right to prosecute traffickers? protections from child labor?)",
        
        "Residents know it is a violation of human rights to use force, threat, or fraud to compel someone to go to a workplace or prevent someone from leaving a job.",

        "Residents are clearly and non-violently able to communicate their rights to officials and others in power.",

        "Residents know how to demand and obtain benefits to which they may be entitled from the government. (facilitator questions: How many residents do you think know how to demand birth registration? pensions? social security? basic social services such as health care and education?)",

        "Residents have economic stability.(facilitator questions: how many families have enough steady income to allow them to withstand unexpected financial demands (such as a family medical emergency) while continuing to eat properly, be housed and attend school? How many families have income generating projects?",

        "Children in this community attend school.",

        "Residents can obtain loans on fair terms.",

        "Residents have enough food throughout the year.",

        "Residents have adequate housing.",

        "Residents have access to essential health care.",

        "Survivors of slavery receive appropriate government compensation according to law.",

        "Child survivors of slavery are attending school.",

       "Adult survivors of slavery are earning a livelihood comparable to others in this community.",

       "Survivors of slavery are accessing essential health care.",

        "Survivors of slavery can access support for psychological trauma.",

        "Survivors of slavery are protected from community-wide stigma.",

        "There is an anti-slavery community group that meets regularly.",

        "The community group has good leadership.",

        "Slavery survivors participate effectively in the group.",

        "Poorer households participate effectively in the group.",

        "Discriminated groups participate effectively in the group.",

        "Women participate effectively in the group.",
        
        "The community group has strong internal cohesion.",

        "The community group is well accepted within the community (while recognizing that those connected with slaveholders and trafficking may not accept the group).",

        "The group can resolve internal disagreements and maintain unity and trust.",
    
        "The group makes its own decisions, without external pressure.",

        "The group develops good plans for keeping the village free from trafficking and slavery.",

        "The group is effective at implementing its plans.",

        "All members participate equitably in carrying out the work of the group.",

        "The group is effective at advocacy with local authorities.",
    
        "The group is effective at reducing slavery in the community.",

        "The group has built strong links with other anti-slavery community groups.",

        ]
    
    
    @IBAction func save(_ sender: AnyObject) {
       UserDefaults.standard.set(comment.text, forKey: "name")
     
        let numberObject = UserDefaults.standard.object(forKey: "name")

        if let num = numberObject as? String{
            print(num)
        }
    }

    
    
    
    @IBAction func selectCompletlyUntrue(_ sender: AnyObject) {
        
        if(count<44){
            count = count + 1;
            question.text = array[count]
            
            comment.text = " "
            name.text = " "
        }
    }
    
    @IBAction func selectedPartiallyTrue(_ sender: AnyObject) {
        if(count<44){
            count = count + 1;
            question.text = array[count]
            comment.text = " "
            name.text = " "


        }

    }
    @IBAction func selectedCompletlyTrue(_ sender: AnyObject) {
        if(count<44){
            count = count + 1;
            question.text = array[count]
            comment.text = " "
            name.text = " "


        }

    }

    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        self.view.endEditing(true)
        return true
    }

  
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        question.text = "Do you expect a form of slavery occuring in your community?"
        count = 0
                
        //Looks for single or multiple taps.
        let tap: UITapGestureRecognizer = UITapGestureRecognizer(target: self, action: #selector(Form.dismissKeyboard))
        
        //Uncomment the line below if you want the tap not not interfere and cancel other interactions.
        //tap.cancelsTouchesInView = false
        
        view.addGestureRecognizer(tap)
    }
    
    //Calls this function when the tap is recognized.
    func dismissKeyboard() {
        //Causes the view (or one of its embedded text fields) to resign the first responder status.
        view.endEditing(true)
    }
    
    
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
}



